# Installing OpenAI Gym:
# 
# Install  OpenAI Gym libraryusing the following command:
# 
# ```bash
# pip install gym
# ```

import gym

# Create the FrozenLake environment
env = gym.make('FrozenLake-v1')
